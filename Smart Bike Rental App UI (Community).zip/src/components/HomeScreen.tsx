import { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, User, Search, Scan, Clock, Wallet, Menu, Bike, Navigation2, Battery } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import type { Screen } from '../App';

interface HomeScreenProps {
  onNavigate: (screen: Screen) => void;
}

const nearbyBikes = [
  { id: 1, type: 'scooter', battery: 95, distance: 0.2, lat: 40.7128, lng: -74.0060 },
  { id: 2, type: 'bike', battery: 78, distance: 0.4, lat: 40.7138, lng: -74.0070 },
  { id: 3, type: 'scooter', battery: 88, distance: 0.6, lat: 40.7148, lng: -74.0080 },
  { id: 4, type: 'bike', battery: 92, distance: 0.8, lat: 40.7118, lng: -74.0050 },
];

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const [showMenu, setShowMenu] = useState(false);

  return (
    <div className="relative w-full h-full bg-white flex flex-col">
      {/* Top Bar */}
      <div className="bg-white px-6 py-4 shadow-sm z-10">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-[#007BFF]" />
            <div>
              <p className="text-gray-500">Current Location</p>
              <p className="text-[#1E1E1E]">Koramangala, Bengaluru</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onNavigate('profile')}
            className="rounded-full w-10 h-10 bg-gradient-to-br from-[#007BFF] to-[#0056b3]"
          >
            <User className="w-5 h-5 text-white" />
          </Button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Search for nearby stations..."
            className="pl-10 h-12 rounded-2xl border-gray-200"
          />
        </div>
      </div>

      {/* Map Area */}
      <div className="flex-1 relative bg-gradient-to-br from-blue-50 to-green-50">
        {/* Mock Map with Markers */}
        <div className="absolute inset-0">
          {nearbyBikes.map((bike, index) => (
            <motion.div
              key={bike.id}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="absolute"
              style={{
                left: `${20 + index * 20}%`,
                top: `${30 + index * 15}%`
              }}
            >
              <div className="relative">
                <div className="w-12 h-12 bg-[#007BFF] rounded-full flex items-center justify-center shadow-lg">
                  {bike.type === 'scooter' ? (
                    <Navigation2 className="w-6 h-6 text-white" />
                  ) : (
                    <Bike className="w-6 h-6 text-white" />
                  )}
                </div>
                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-white px-2 py-1 rounded-lg shadow-sm whitespace-nowrap">
                  <p className="text-[#1E1E1E]">{bike.distance} mi</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* User Location Marker */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative">
            <div className="w-4 h-4 bg-[#007BFF] rounded-full border-4 border-white shadow-lg" />
            <motion.div
              animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 w-4 h-4 bg-[#007BFF] rounded-full"
            />
          </div>
        </div>
      </div>

      {/* Bottom Sheet */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="bg-white rounded-t-3xl shadow-2xl px-6 py-6"
      >
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4" />

        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[#1E1E1E]">Nearby Vehicles</h3>
          <p className="text-gray-500">{nearbyBikes.length} available</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-4 gap-3 mb-4">
          <Button
            onClick={() => onNavigate('scan')}
            className="h-auto py-4 flex flex-col gap-2 bg-gradient-to-br from-[#007BFF] to-[#0056b3] hover:from-[#0056b3] hover:to-[#003d82] rounded-2xl"
          >
            <Scan className="w-6 h-6" />
            <span className="text-xs">Scan</span>
          </Button>
          <Button
            onClick={() => onNavigate('history')}
            variant="outline"
            className="h-auto py-4 flex flex-col gap-2 rounded-2xl border-2"
          >
            <Clock className="w-6 h-6 text-[#007BFF]" />
            <span className="text-xs text-[#1E1E1E]">Rides</span>
          </Button>
          <Button
            onClick={() => onNavigate('wallet')}
            variant="outline"
            className="h-auto py-4 flex flex-col gap-2 rounded-2xl border-2"
          >
            <Wallet className="w-6 h-6 text-[#007BFF]" />
            <span className="text-xs text-[#1E1E1E]">Wallet</span>
          </Button>
          <Button
            onClick={() => setShowMenu(!showMenu)}
            variant="outline"
            className="h-auto py-4 flex flex-col gap-2 rounded-2xl border-2"
          >
            <Menu className="w-6 h-6 text-[#007BFF]" />
            <span className="text-xs text-[#1E1E1E]">More</span>
          </Button>
        </div>

        {/* Menu Options */}
        {showMenu && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-2 mb-4"
          >
            <Button
              onClick={() => onNavigate('support')}
              variant="ghost"
              className="w-full justify-start rounded-xl"
            >
              Support & Help
            </Button>
            <Button
              onClick={() => onNavigate('admin')}
              variant="ghost"
              className="w-full justify-start rounded-xl"
            >
              Admin Dashboard
            </Button>
          </motion.div>
        )}

        {/* Vehicle List */}
        <div className="space-y-2 max-h-32 overflow-auto">
          {nearbyBikes.map((bike) => (
            <Card key={bike.id} className="p-3 rounded-2xl border-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#007BFF]/10 to-[#A6FF00]/10 rounded-xl flex items-center justify-center">
                    {bike.type === 'scooter' ? (
                      <Navigation2 className="w-6 h-6 text-[#007BFF]" />
                    ) : (
                      <Bike className="w-6 h-6 text-[#007BFF]" />
                    )}
                  </div>
                  <div>
                    <p className="text-[#1E1E1E]">
                      {bike.type === 'scooter' ? 'E-Scooter' : 'E-Bike'} #{bike.id}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <Battery className="w-4 h-4 text-[#A6FF00]" />
                      <span className="text-gray-600">{bike.battery}%</span>
                      <span className="text-gray-400">•</span>
                      <span className="text-gray-600">{bike.distance} mi away</span>
                    </div>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => onNavigate('scan')}
                  className="bg-[#A6FF00] text-[#1E1E1E] hover:bg-[#95ee00] rounded-xl"
                >
                  Unlock
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
