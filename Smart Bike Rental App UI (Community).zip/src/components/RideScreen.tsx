import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Clock, MapPin, DollarSign, Battery, Shield, Navigation2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';

interface RideScreenProps {
  onEndRide: (data: { duration: number; distance: number; fare: number }) => void;
}

export function RideScreen({ onEndRide }: RideScreenProps) {
  const [duration, setDuration] = useState(0);
  const [distance, setDistance] = useState(0);
  const [fare, setFare] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setDuration((prev) => prev + 1);
      setDistance((prev) => prev + 0.05);
      setFare((prev) => prev + 1.5);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndRide = () => {
    onEndRide({ duration, distance: parseFloat(distance.toFixed(2)), fare: parseFloat(fare.toFixed(2)) });
  };

  return (
    <div className="relative w-full h-full bg-gradient-to-br from-[#007BFF] to-[#0056b3] flex flex-col">
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{ 
          backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)',
          backgroundSize: '20px 20px'
        }} />
      </div>

      {/* Status Bar */}
      <div className="relative z-10 px-6 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-[#A6FF00] rounded-full animate-pulse" />
            <span className="text-white">Ride in Progress</span>
          </div>
          <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
            <Battery className="w-4 h-4 text-[#A6FF00]" />
            <span className="text-white">87%</span>
          </div>
        </div>
      </div>

      {/* Main Stats */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 relative z-10">
        {/* Timer Circle */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="relative mb-8"
        >
          <div className="w-48 h-48 rounded-full bg-white/10 backdrop-blur-md border-4 border-white/20 flex flex-col items-center justify-center">
            <Clock className="w-8 h-8 text-[#A6FF00] mb-2" />
            <p className="text-5xl text-white">{formatTime(duration)}</p>
            <p className="text-white/70 mt-1">Duration</p>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="w-full grid grid-cols-2 gap-4">
          <Card className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border-2 border-white/20">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="w-5 h-5 text-[#A6FF00]" />
              <span className="text-white/70">Distance</span>
            </div>
            <p className="text-white text-2xl">{distance.toFixed(2)}</p>
            <p className="text-white/70">miles</p>
          </Card>

          <Card className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border-2 border-white/20">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-5 h-5 text-[#A6FF00]" />
              <span className="text-white/70">Fare</span>
            </div>
            <p className="text-white text-2xl">₹{fare.toFixed(2)}</p>
            <p className="text-white/70">estimated</p>
          </Card>
        </div>

        {/* Mini Map Preview */}
        <Card className="w-full mt-4 p-3 rounded-2xl bg-white/10 backdrop-blur-md border-2 border-white/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-white">Current Route</span>
            <Navigation2 className="w-5 h-5 text-[#A6FF00]" />
          </div>
          <div className="h-20 bg-white/10 rounded-xl flex items-center justify-center">
            <div className="relative w-full h-full">
              <motion.div
                animate={{ x: [0, 100, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute w-2 h-2 bg-[#A6FF00] rounded-full top-1/2 left-4"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-0.5 bg-white/20" />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Safety Reminder */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="relative z-10 mx-6 mb-4"
      >
        <Card className="p-3 rounded-2xl bg-[#A6FF00]/20 backdrop-blur-md border-2 border-[#A6FF00]/30">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-[#A6FF00]" />
            <div>
              <p className="text-white">Safety First!</p>
              <p className="text-white/70">Wear your helmet and follow traffic rules</p>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* End Ride Button */}
      <div className="relative z-10 px-6 pb-6">
        <Button
          onClick={handleEndRide}
          className="w-full bg-white text-[#007BFF] hover:bg-gray-100 rounded-2xl h-14 shadow-lg"
        >
          End Ride
        </Button>
      </div>
    </div>
  );
}
